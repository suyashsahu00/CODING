import pandas as pd

# Load the dataset
df = pd.read_csv('Vocational Training/IIIT Naya Raipur/Python/05-07-25/Task-1/Cost_of_Living_Index_by_Country_2024.csv')

# Add a new column: 'Cost_Rent_Product' = 'Cost of Living Index' * 'Rent Index'
df['Cost_Rent_Product'] = df['Cost of Living Index'] * df['Rent Index']

# Display the first few rows with the new column
print(df.head())
