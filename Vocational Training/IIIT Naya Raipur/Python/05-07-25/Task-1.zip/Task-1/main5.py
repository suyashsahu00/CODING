
# Import pandas
import pandas as pd

# Load the first dataset: Cost of Living Index by Country 2024
df1 = pd.read_csv('Cost_of_Living_Index_by_Country_2024.csv')

# Placeholder for the second related dataset (replace with actual filename if available)
# For demonstration, let's create a simple DataFrame as df2
data2 = {
    'Country': ['Switzerland', 'Bahamas', 'Iceland', 'Singapore', 'Barbados'],
    'Population (millions)': [8.7, 0.4, 0.37, 5.9, 0.29]
}
df2 = pd.DataFrame(data2)

# Display the first few rows of both DataFrames
print('First dataset (Cost of Living Index):')
print(df1.head())
print('\nSecond dataset (example, replace with real data if available):')
print(df2.head())

import pandas as pd

# Load the first dataset: Cost of Living Index by Country 2024
df_cost_of_living = pd.read_csv('Cost_of_Living_Index_by_Country_2024.csv')

# Load the second dataset (replace with actual filename if different)
# Example: df_other = pd.read_csv('other_dataset.csv')
df_other = pd.DataFrame()  # Placeholder for the second DataFrame

# Display the first few rows of both DataFrames
print("Cost of Living Index DataFrame:")
print(df_cost_of_living.head())
print("\nSecond DataFrame (replace with actual data):")
print(df_other.head())
