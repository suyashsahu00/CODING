
# Import pandas
import pandas as pd

# Load the first dataset: Cost of Living Index by Country 2024
df1 = pd.read_csv(r'c:\Users\suyas\OneDrive\Desktop\CODING\CODING\Vocational Training\IIIT Naya Raipur\Python\05-07-25\Task-1\Cost_of_Living_Index_by_Country_2024.csv')

# Example second dataset (replace with your actual second dataset if available)
data2 = {
    'Country': ['Switzerland', 'Bahamas', 'Iceland', 'Singapore', 'Barbados'],
    'Population (millions)': [8.7, 0.4, 0.37, 5.9, 0.29]
}
df2 = pd.DataFrame(data2)

# Perform an inner join on the 'Country' column
merged_df = pd.merge(df1, df2, on='Country', how='inner')

# Display the result
print('Result of inner join:')
print(merged_df)
