import pandas as pd

# Load the dataset
df = pd.read_csv('Vocational Training/IIIT Naya Raipur/Python/05-07-25/Task-1/Cost_of_Living_Index_by_Country_2024.csv')

# Sort the DataFrame by 'Cost of Living Index' in descending order
sorted_df = df.sort_values(by='Cost of Living Index', ascending=False)
print(sorted_df)
