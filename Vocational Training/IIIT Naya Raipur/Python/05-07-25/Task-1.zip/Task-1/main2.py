import pandas as pd

# Load the dataset with the correct relative path
df = pd.read_csv('Vocational Training/IIIT Naya Raipur/Python/05-07-25/Task-1/Cost_of_Living_Index_by_Country_2024.csv')
# Filter rows where 'Rent Index' is greater than 40
filtered_df = df[df['Rent Index'] > 40]
print(filtered_df)
